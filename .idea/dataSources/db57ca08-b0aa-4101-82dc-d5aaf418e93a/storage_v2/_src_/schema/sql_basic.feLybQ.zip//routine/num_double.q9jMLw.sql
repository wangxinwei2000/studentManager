create
    definer = root@localhost procedure num_double(INOUT num1 int, INOUT num2 int)
begin
    set num1 = num1*2;
    set num2 = num2*2;
end;

