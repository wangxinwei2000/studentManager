create
    definer = root@localhost procedure myp2(IN goodStudent varchar(20))
begin
    declare class_code varchar(20) default '02';
    select * from student where StudentName = goodStudent and ClassCode=class_code;
end;

