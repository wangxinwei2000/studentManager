create
    definer = root@localhost procedure myp3(IN student_Name varchar(20), OUT class_Code varchar(10))
begin
    select ClassCode into class_Code from student where student.StudentName = Student_Name;
end;

